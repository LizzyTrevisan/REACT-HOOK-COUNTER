import React, {useState} from 'react'; // library for the hook React

function MyComponent (){

    const [name, setName] = useState();//inside the parentheses it will the initial state passed, in this case empty.
    const [age, setAge] = useState(0);
    const [isEmployee,setIsEmployed]= useState(false);

    const updateName = () => {
        setName("Lizzy");
    }

    const incrementAge = () =>
    {
        setAge(age + 1);   
    }

    const toggleEmployedStatus = () =>
    {
        setIsEmployed(!isEmployee);
    }



return (

<div>
    <p>Name: {name} </p>
        <button onClick={updateName}>Set Name</button>

    <p>Age: {age} </p>
        <button onClick={incrementAge}>Increment Age</button>
  
    <p>Employee: {isEmployee ? "Yes" : "No"} </p>
        <button onClick={toggleEmployedStatus}>Employee</button>
</div>
    
);


}

export default MyComponent