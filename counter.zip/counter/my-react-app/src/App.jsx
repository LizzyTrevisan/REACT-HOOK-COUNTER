import MyComponent from './MyComponent.jsx';
import Counter from'./Counter.jsx';

function App() {
  
  return (
    <>

    <Counter/>
   
    </>
  )
}

export default App
